<script setup lang="ts">

</script>

<template>
<h1>热门</h1>
</template>

<style scoped>

</style>